
function [rn foo ]= RegualrizedMinResidualMtd_alpha(J,foo,data_diff,alpha)

r = convolve2(foo,J,'wrap')- data_diff;
eps = 0.00001*norm(data_diff);
rprev = r ;
itt = 1;
err_pj = 20;
rn_p = norm(rprev,2);
ln = convolve2(r,J,'wrap')+ alpha * (foo);
%   First term is the problem
gn = convolve2(ln,J,'wrap');
%kn = (norm(ln,2)^2)/(norm(gn,2)^2);
kn = (norm(ln,2)^2)/(norm(gn,2)^2 + alpha * norm(ln,2)^2);
foo = foo - kn*ln;
rprev =r;     
r =  convolve2(foo,J,'wrap') - data_diff;
rn = norm(r,2);
err_pj = ((rn_p - rn)/(rn_p))*100;
itt = itt +1;
          

 
                 
