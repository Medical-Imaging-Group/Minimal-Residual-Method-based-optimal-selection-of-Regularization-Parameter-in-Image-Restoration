
%% IMAGE RESTORE
close all; clear all;clc;
%% read image  


x= imread('cells.jpg');

x=double(x);

[N C] = size(x); %N=rows C=cols

%figure ;imshow(x,[])

%% FORWARD MODEL

%variables used 
% TIK-FFT blurred image - Bbig
% conv blurred image - bconv
% blurring for  TIK-fft
[P, center] = psfGauss([N,C],1);
% Create a PSF array whose size matches the large image.
Pbig = padPSF(P, size(N));
% Compute the blurred large image by a convolution of the sharp
% large image with the corresponding PSF.
Sbig = fft2(circshift(Pbig, 1-center));  % Eigenvalue of big PSF.
Bbig = real(ifft2(Sbig .* fft2(x)));  % Blurred large image

% blurring for  MRM-CONVOVLE
PSF = fspecial('gaussian',11,1);
%  tc1 = tic;
bconv = convolve2(x,PSF,'wrap');



%% ADD NOISE
init= zeros(N*C,1);
initconv= zeros(N,C);
pernoise=0;%percentage of noise
xexact= double(reshape(x,N*C,1));
close all
k=0 ;
E = poissrnd(0.5,N,C);
E=E/norm(E);

for nl= 1:11 %loop counter
    
    
k=k+1;
sc = pernoise/100 % 
% adding noise to the convolved blurred image
bcnoise=bconv+(sc)*norm(bconv)*E; % convolved blurred noisy image

% adding noise to the TIK-FFT blurred image
Bbignoise = Bbig+(sc)*norm(Bbig)*E;

% THE BLURRED NOISY IMAGES IN EACH ITERATION OF NOISE ADDED 
btik_fft(:,:,k)= Bbignoise;
bcn(:,:,k)= bcnoise;

display('TIKHONOV')

[fgcvtik(:,:,k), alphagcv(k)] = tik_fft(Bbignoise, P, center);
[ro_tik fgcvmrm(:,:,k)] = RegualrizedMinResidualMtdver_restore(PSF,initconv,double(bcnoise),alphagcv(k));


display('MRM Starts')


aplhamrm(k) = fminbnd(@(alpha) RegualrizedMinResidualMtd_alpha(PSF,initconv,double(bcnoise),alpha),...
                          0, 1, ...
    optimset('Display','iter', 'MaxIter', 1000, 'MaxFunEvals', 1000, 'TolX', 1e-16));

[ro_mrm fmrmmrm(:,:,k)] = RegualrizedMinResidualMtdver_restore(PSF,initconv,double(bcnoise),aplhamrm(k));fmrmtik(:,:,k) = tik_restoration(Bbignoise, P, center, aplhamrm(k));



pernoise = pernoise+5;



end 


